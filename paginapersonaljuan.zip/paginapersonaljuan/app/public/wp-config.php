<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'hL}wa}leNF2wM`^E]:BoS+87L+z#{k4LW1+j=L]/AS2|yBdXu>)BG:P).]FY7s:W' );
define( 'SECURE_AUTH_KEY',   'UiPK) `/&T<.!=ki#E-U~slt>r}n|(w23`bs#[obc-ruI]Z-nti:MS{!`?i}j2Q/' );
define( 'LOGGED_IN_KEY',     'g(0F./HVcLLg?A`-<J2>#Eyj]:sh}R$Bc4KkfqK^x9,E83R(Wq6#@,8UmP9S^._Y' );
define( 'NONCE_KEY',         'j7k7LQ@[c>L}@E4g7*kVZUN^-S(/,VyEP@a=UL$$1dn>Z}fP(-xn/5M.Q~/q=uC/' );
define( 'AUTH_SALT',         'oCZ8wS@-+>vq#xI#qW!q=<V<2$iEb^FubJwd|hz2+{doM=`uOqLl1El~<i53*Qdl' );
define( 'SECURE_AUTH_SALT',  ' D7~3xl9WwdQUY?rec.,&)Jj_ThNuxOAM-tc 13FR;&~Ron#1?ZxjiV<6Qpoqg_m' );
define( 'LOGGED_IN_SALT',    'MaqM(({*#<{Hu7r8?NAuiOMP!Q.,ItBq!k=l3RYp+PfC^gyJlm+LkI8jg8~L|&1B' );
define( 'NONCE_SALT',        'EB{U}33kYMxG=S_*&xauZ<k[~-,n!vyp1MdyG&IW1]2Og9X/rw:y9bJiofoR=-hL' );
define( 'WP_CACHE_KEY_SALT', 'SoDZ1SWE2s8_YWiA?`{^S8*8hfpUhf:hdm; Q09:$B1d:MuSL<%;_e-~KM{[ELbz' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
