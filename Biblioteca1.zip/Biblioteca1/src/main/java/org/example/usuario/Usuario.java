package org.example.usuario;

public class Usuario {
    private String dni;
    private String nombre;

}
